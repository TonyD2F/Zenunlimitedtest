# OpenCode Unlimited

**Single local OpenAI / Anthropic-compatible gateway** that combines the strongest ideas from the major community “unlimited” repos for OpenCode Zen free models.

| Source repo | What we took |
|---|---|
| [Parsa013Ah/OpenCode-Unlimited-ProxyPool](https://github.com/Parsa013Ah/OpenCode-Unlimited-ProxyPool) | Personal + public proxy pool, disk cache, V2Ray-ready config layout, dashboard, Node/Express shape |
| [ebouther/opencode-unlimited-proxy](https://github.com/ebouther/opencode-unlimited-proxy) | Free-tier fingerprint gates (`stream: true`, tool named `read`), rotate-on-403/429, explicit “does not remove quota” stance |
| [Tazmyan/OpenCode-Unlimited](https://github.com/Tazmyan/OpenCode-Unlimited) | Identity / project-id rotation guidance, status CLI, proxy routing notes |
| [Netherstar44/OpenCode_Unlimited](https://github.com/Netherstar44/OpenCode_Unlimited) | Process hygiene & cache-reset guidance adapted for Linux/proot |

Designed for **Debian proot** (Termux, proot-distro, etc.): pure Node, no Docker, low memory.

> **ToS note.** Rotating egress or identity to multiply free-tier budget may violate OpenCode’s terms. This project does not claim affiliation with OpenCode / Anomaly. Use at your own risk.

---

## Quick start (Debian proot)

```bash
# Node 18+ required
cd opencode-unlimited
npm install
cp config/custom-proxies.example.txt config/custom-proxies.txt
# edit custom-proxies.txt with your SOCKS/HTTP proxies (strongly recommended)

npm start
```

- Dashboard: http://127.0.0.1:8787/
- OpenAI base URL: `http://127.0.0.1:8787/v1`
- API key: any string (default `openAuth`)
- Health: `http://127.0.0.1:8787/health`

```bash
curl http://127.0.0.1:8787/v1/models
curl http://127.0.0.1:8787/v1/chat/completions \
  -H "Authorization: Bearer local" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4.1-flash-free","messages":[{"role":"user","content":"hi"}],"stream":true}'
```

### Point OpenCode at the gateway

In `opencode.json` (project or global):

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "unlimited": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "OpenCode Unlimited",
      "options": {
        "baseURL": "http://127.0.0.1:8787/v1",
        "apiKey": "local"
      },
      "models": {
        "deepseek-v4.1-flash-free": { "name": "DeepSeek V4.1 Flash Free" },
        "glm-5.3-flash-free": { "name": "GLM 5.3 Flash Free" }
      }
    }
  }
}
```

(Exact provider schema may vary by OpenCode version; use `/models` or the live list from the gateway.)

---

## CLI

```bash
npx opencode-unlimited status      # config + OpenCode paths
npx opencode-unlimited health     # live gateway status
npx opencode-unlimited proxy add 'socks5://127.0.0.1:1080'
npx opencode-unlimited proxy list
npx opencode-unlimited id-hint    # identity rotation (Tazmyan-style)
npx opencode-unlimited reset-hint # process hygiene (Netherstar-style)
```

---

## Proxies

**Personal proxies are required for reliable free-tier access.** Public lists rarely survive OpenCode’s checks.

1. Copy `config/custom-proxies.example.txt` → `config/custom-proxies.txt`
2. Add one proxy per line (`socks5://…`, `http://…`, etc.)
3. Or set `PROXY_CUSTOM=socks5://…,http://…`

V2Ray share links / subscriptions: put them in `config/v2ray.txt` (layout ready; full Xray-core manager can be added later — current release focuses on classic HTTP/SOCKS + fingerprint + rotation).

---

## Environment

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | `8787` | Listen port |
| `BIND` | `127.0.0.1` | Bind address |
| `PROXY_ENABLED` | `1` | Enable pool |
| `PROXY_CUSTOM` | — | Comma-separated personal proxies |
| `OPENCODE_UPSTREAM` | `https://opencode.ai/zen/v1` | Primary upstream |

---

## What this does **not** do

- Does not remove upstream per-egress-block quotas (daily reset ~00:00 UTC).
- Does not ship Cloudflare WARP (ebouther’s Docker/WARP path needs privileged networking unsuitable for typical proot).
- Does not auto-edit OpenCode identity files (CLI only prints safe steps).

---

## License

MIT. Community-derived ideas; original implementation. Not affiliated with OpenCode, Anomaly, or the upstream authors of the referenced repos.
