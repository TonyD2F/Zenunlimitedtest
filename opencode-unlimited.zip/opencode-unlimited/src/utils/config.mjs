import fs from 'node:fs';
import { CONFIG_JSON, ensureDirs } from './paths.mjs';

const DEFAULTS = {
  port: Number(process.env.PORT) || 8787,
  bind: process.env.BIND || '127.0.0.1',
  proxyEnabled: process.env.PROXY_ENABLED !== '0',
  openAuth: true,
  upstream: process.env.OPENCODE_UPSTREAM || 'https://opencode.ai/zen/v1',
  upstreamAlt: 'https://opencode.ai/inference/openai/v1',
  maxRetries: 4,
  proxyPoolSize: 40,
  scanConcurrency: 80,
  modelRefreshMs: 30 * 60 * 1000,
  fingerprint: {
    // Critical free-tier gates observed in community tools
    forceStream: true,
    injectReadTool: true,
    userAgent: 'opencode/2.0'
  }
};

export function loadConfig() {
  ensureDirs();
  let user = {};
  try {
    if (fs.existsSync(CONFIG_JSON)) {
      user = JSON.parse(fs.readFileSync(CONFIG_JSON, 'utf8'));
    }
  } catch {}
  return { ...DEFAULTS, ...user };
}

export function saveConfig(cfg) {
  ensureDirs();
  fs.writeFileSync(CONFIG_JSON, JSON.stringify(cfg, null, 2));
}
