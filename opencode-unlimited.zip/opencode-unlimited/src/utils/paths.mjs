import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '../..');
export const CONFIG_DIR = path.join(ROOT, 'config');
export const DATA_DIR = path.join(ROOT, 'data');
export const CUSTOM_PROXIES = path.join(CONFIG_DIR, 'custom-proxies.txt');
export const V2RAY_FILE = path.join(CONFIG_DIR, 'v2ray.txt');
export const PROXY_CACHE = path.join(DATA_DIR, 'proxy-cache.json');
export const CONFIG_JSON = path.join(DATA_DIR, 'config.json');
export const STATS_FILE = path.join(DATA_DIR, 'stats.json');

export function ensureDirs() {
  for (const d of [DATA_DIR, CONFIG_DIR]) {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  }
}
