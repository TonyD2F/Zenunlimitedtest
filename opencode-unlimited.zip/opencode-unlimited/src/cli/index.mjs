#!/usr/bin/env node
/**
 * CLI helpers inspired by Tazmyan OpenCode-Unlimited + Netherstar process hygiene.
 * Focused on status, identity rotation notes, and proxy config for Debian/proot.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { loadConfig } from '../utils/config.mjs';
import { CUSTOM_PROXIES, ensureDirs } from '../utils/paths.mjs';

const [,, cmd = 'help', ...args] = process.argv;

function help() {
  console.log(`
opencode-unlimited — unified OpenCode free-tier gateway + helpers

Commands:
  start                 Start the local gateway (same as npm start)
  status                Show config + common OpenCode paths
  health                GET /health on the running gateway
  proxy add <url>       Append a personal proxy to config/custom-proxies.txt
  proxy list            List personal proxies
  id-hint               Print how to rotate OpenCode project identity (Tazmyan-style)
  reset-hint            Print process / cache cleanup notes (Netherstar-style)
  help                  This message

Gateway:
  OpenAI base URL:  http://127.0.0.1:8787/v1
  API key:          any string (openAuth)
`);
}

async function status() {
  const cfg = loadConfig();
  console.log('Config:');
  console.log(`  port/bind     ${cfg.bind}:${cfg.port}`);
  console.log(`  upstream      ${cfg.upstream}`);
  console.log(`  proxyEnabled  ${cfg.proxyEnabled}`);
  console.log(`  personal file ${CUSTOM_PROXIES}`);
  console.log('');
  console.log('Common OpenCode paths (Linux / proot):');
  const home = os.homedir();
  const candidates = [
    path.join(home, '.config/opencode'),
    path.join(home, '.local/share/opencode'),
    path.join(home, '.opencode'),
    path.join(home, '.config/opencode/identity.json'),
    path.join(home, '.config/opencode/plugins')
  ];
  for (const p of candidates) {
    console.log(`  ${fs.existsSync(p) ? '✓' : '·'} ${p}`);
  }
}

async function health() {
  const cfg = loadConfig();
  try {
    const r = await fetch(`http://${cfg.bind === '0.0.0.0' ? '127.0.0.1' : cfg.bind}:${cfg.port}/health`);
    const j = await r.json();
    console.log(JSON.stringify(j, null, 2));
  } catch (e) {
    console.error('Gateway not reachable:', e.message);
    process.exit(1);
  }
}

function proxyAdd(url) {
  if (!url) {
    console.error('Usage: opencode-unlimited proxy add <proxy-url>');
    process.exit(1);
  }
  ensureDirs();
  fs.appendFileSync(CUSTOM_PROXIES, url.trim() + '\n');
  console.log('Added personal proxy. Restart gateway to load it.');
}

function proxyList() {
  ensureDirs();
  if (!fs.existsSync(CUSTOM_PROXIES)) {
    console.log('(no personal proxies yet — copy config/custom-proxies.example.txt)');
    return;
  }
  console.log(fs.readFileSync(CUSTOM_PROXIES, 'utf8'));
}

function idHint() {
  console.log(`
Identity rotation (from Tazmyan/OpenCode-Unlimited approach):

OpenCode free limits are often tied to project/device identity + egress IP.
Typical locations on Linux/proot:

  ~/.config/opencode/identity.json
  ~/.opencode/identity.json
  ~/.local/share/opencode/

Safe workflow:
  1. Change egress (VPN / new proxy / new WARP exit).
  2. Stop OpenCode.
  3. Move or delete identity.json (or only the projectId field).
  4. Restart OpenCode — it mints a fresh project id.
  5. Route OpenCode through this gateway:
       base URL http://127.0.0.1:8787/v1

This CLI does not rewrite OpenCode state automatically (safer on shared proot).
`);
}

function resetHint() {
  console.log(`
Process / cache hygiene (inspired by Netherstar44/OpenCode_Unlimited):

On Linux / Debian proot:

  # stop leftover opencode processes
  pkill -f opencode || true

  # optional: clear large session DBs if quota burns unusually fast
  # (only if you accept losing local chat history)
  # rm -rf ~/.local/share/opencode/*.db

  # then start this gateway and point the client at it
  npm start

Windows users of the original .bat still use process kill + .updaterId rotation;
those steps are Windows-specific and intentionally omitted here.
`);
}

switch (cmd) {
  case 'start':
    await import('../server.mjs');
    break;
  case 'status':
    await status();
    break;
  case 'health':
    await health();
    break;
  case 'proxy':
    if (args[0] === 'add') proxyAdd(args[1]);
    else if (args[0] === 'list') proxyList();
    else help();
    break;
  case 'id-hint':
  case 'id':
    idHint();
    break;
  case 'reset-hint':
  case 'reset':
    resetHint();
    break;
  default:
    help();
}
