/**
 * Parse common proxy line formats into a normalized object.
 */
export function parseProxyLine(line) {
  line = (line || '').trim();
  if (!line || line.startsWith('#')) return null;

  // scheme://[user:pass@]host:port
  const urlMatch = line.match(/^(https?|socks[45]?):\/\/(?:([^:@]+):([^@]+)@)?([^:\/]+):(\d+)/i);
  if (urlMatch) {
    return {
      protocol: urlMatch[1].toLowerCase().replace('socks', 'socks'),
      host: urlMatch[4],
      port: Number(urlMatch[5]),
      auth: urlMatch[2] ? `${urlMatch[2]}:${urlMatch[3]}` : null,
      raw: line
    };
  }

  // user:pass@host:port
  const authMatch = line.match(/^([^:@]+):([^@]+)@([^:]+):(\d+)$/);
  if (authMatch) {
    return {
      protocol: 'http',
      host: authMatch[3],
      port: Number(authMatch[4]),
      auth: `${authMatch[1]}:${authMatch[2]}`,
      raw: line
    };
  }

  // host:port:user:pass
  const parts = line.split(':');
  if (parts.length === 4 && !isNaN(parts[1])) {
    return {
      protocol: 'http',
      host: parts[0],
      port: Number(parts[1]),
      auth: `${parts[2]}:${parts[3]}`,
      raw: line
    };
  }

  // host:port
  if (parts.length === 2 && !isNaN(parts[1])) {
    return {
      protocol: 'http',
      host: parts[0],
      port: Number(parts[1]),
      auth: null,
      raw: line
    };
  }

  // http|host:port  or  socks5:host:port
  const pipe = line.match(/^(https?|socks[45]?)[|:]([^:]+):(\d+)$/i);
  if (pipe) {
    return {
      protocol: pipe[1].toLowerCase(),
      host: pipe[2],
      port: Number(pipe[3]),
      auth: null,
      raw: line
    };
  }

  return null;
}

export function toProxyUrl(p) {
  if (!p) return null;
  const proto = p.protocol.startsWith('socks') ? p.protocol : 'http';
  if (p.auth) return `${proto}://${p.auth}@${p.host}:${p.port}`;
  return `${proto}://${p.host}:${p.port}`;
}
