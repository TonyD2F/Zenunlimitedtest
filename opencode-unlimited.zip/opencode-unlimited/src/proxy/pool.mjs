import fs from 'node:fs';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { SocksProxyAgent } from 'socks-proxy-agent';
import { parseProxyLine, toProxyUrl } from './parser.mjs';
import { CUSTOM_PROXIES, PROXY_CACHE, ensureDirs } from '../utils/paths.mjs';

const PUBLIC_SOURCES = [
  // Minimal set of public lists (many community tools use 100+; keep light for proot)
  'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
  'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
  'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
  'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=5000',
  'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=5000'
];

export class ProxyPool {
  constructor(opts = {}) {
    this.enabled = opts.enabled !== false;
    this.poolSize = opts.poolSize || 40;
    this.concurrency = opts.concurrency || 60;
    this.personal = [];
    this.public = [];
    this.banned = new Map(); // key -> until timestamp
    this.stats = { success: 0, fail: 0, rotate: 0 };
    this._idx = 0;
  }

  async init() {
    ensureDirs();
    this.loadPersonal();
    this.loadCache();
    if (this.enabled) {
      // Background refresh; do not block startup
      this.refreshPublic().catch(() => {});
      setInterval(() => this.refreshPublic().catch(() => {}), 15 * 60 * 1000);
    }
  }

  loadPersonal() {
    this.personal = [];
    try {
      if (fs.existsSync(CUSTOM_PROXIES)) {
        const lines = fs.readFileSync(CUSTOM_PROXIES, 'utf8').split(/\r?\n/);
        for (const line of lines) {
          const p = parseProxyLine(line);
          if (p) {
            p.personal = true;
            this.personal.push(p);
          }
        }
      }
    } catch {}
    // Env override
    const env = process.env.PROXY_CUSTOM || '';
    for (const part of env.split(/[,\n]/)) {
      const p = parseProxyLine(part);
      if (p) {
        p.personal = true;
        this.personal.push(p);
      }
    }
  }

  loadCache() {
    try {
      if (fs.existsSync(PROXY_CACHE)) {
        const data = JSON.parse(fs.readFileSync(PROXY_CACHE, 'utf8'));
        this.public = (data.proxies || []).map(p => ({ ...p, personal: false }));
      }
    } catch {}
  }

  saveCache() {
    try {
      ensureDirs();
      fs.writeFileSync(PROXY_CACHE, JSON.stringify({
        updated: Date.now(),
        proxies: this.public.slice(0, this.poolSize)
      }, null, 2));
    } catch {}
  }

  async refreshPublic() {
    const candidates = new Set();
    for (const url of PUBLIC_SOURCES) {
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 12000);
        const res = await fetch(url, { signal: ctrl.signal });
        clearTimeout(t);
        if (!res.ok) continue;
        const text = await res.text();
        for (const line of text.split(/\r?\n/)) {
          const p = parseProxyLine(line.trim());
          if (p) candidates.add(`${p.protocol}|${p.host}|${p.port}|${p.auth || ''}`);
        }
      } catch {}
    }
    // Keep existing good ones + new candidates (simple; full connectivity test is heavy for proot)
    const existing = new Set(this.public.map(p => `${p.protocol}|${p.host}|${p.port}|${p.auth || ''}`));
    for (const key of candidates) {
      if (existing.has(key)) continue;
      const [protocol, host, port, auth] = key.split('|');
      this.public.push({
        protocol,
        host,
        port: Number(port),
        auth: auth || null,
        personal: false,
        raw: key
      });
    }
    // Cap
    if (this.public.length > this.poolSize * 3) {
      this.public = this.public.slice(0, this.poolSize * 3);
    }
    this.saveCache();
  }

  isBanned(p) {
    const key = `${p.host}:${p.port}`;
    const until = this.banned.get(key);
    if (!until) return false;
    if (Date.now() > until) {
      this.banned.delete(key);
      return false;
    }
    return true;
  }

  ban(p, ms = 5 * 60 * 1000) {
    this.banned.set(`${p.host}:${p.port}`, Date.now() + ms);
  }

  next() {
    if (!this.enabled) return null;
    const list = [...this.personal, ...this.public].filter(p => !this.isBanned(p));
    if (!list.length) return null;
    this._idx = (this._idx + 1) % list.length;
    this.stats.rotate++;
    return list[this._idx];
  }

  agentFor(p) {
    if (!p) return undefined;
    const url = toProxyUrl(p);
    if (!url) return undefined;
    if (p.protocol.startsWith('socks')) {
      return new SocksProxyAgent(url);
    }
    return new HttpsProxyAgent(url);
  }

  status() {
    return {
      enabled: this.enabled,
      personal: this.personal.length,
      public: this.public.length,
      banned: this.banned.size,
      stats: this.stats
    };
  }
}
