import { ProxyAgent, fetch as undiciFetch } from 'undici';
import { toProxyUrl } from './parser.mjs';

/**
 * Apply free-tier fingerprint gates observed by community tools
 * (ebouther free-tier-gates, ProxyPool behaviour).
 */
export function applyFingerprint(body, cfg) {
  const out = { ...body };
  if (cfg.fingerprint?.forceStream) {
    out.stream = true;
  }
  // Some free-tier gates expect a tools array containing a tool named exactly "read"
  if (cfg.fingerprint?.injectReadTool && Array.isArray(out.tools)) {
    const hasRead = out.tools.some(t => t?.function?.name === 'read' || t?.name === 'read');
    if (!hasRead) {
      out.tools = [
        ...out.tools,
        {
          type: 'function',
          function: {
            name: 'read',
            description: 'Read a file',
            parameters: { type: 'object', properties: { path: { type: 'string' } } }
          }
        }
      ];
    }
  } else if (cfg.fingerprint?.injectReadTool && !out.tools) {
    // Only inject when tools are already expected; avoid breaking pure chat
  }
  return out;
}

export async function callUpstream({ url, method = 'POST', headers = {}, body, proxy, timeoutMs = 60000 }) {
  const opts = {
    method,
    headers: {
      'content-type': 'application/json',
      'user-agent': headers['user-agent'] || 'opencode/2.0',
      ...headers
    },
    body: body ? JSON.stringify(body) : undefined
  };

  // Prefer undici ProxyAgent when we have a proxy URL
  if (proxy) {
    const proxyUrl = toProxyUrl(proxy);
    if (proxyUrl) {
      const agent = new ProxyAgent(proxyUrl);
      opts.dispatcher = agent;
    }
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  opts.signal = ctrl.signal;

  try {
    const res = await undiciFetch(url, opts);
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch {}
    return {
      ok: res.ok,
      status: res.status,
      headers: Object.fromEntries(res.headers.entries()),
      body: json ?? text,
      raw: text
    };
  } finally {
    clearTimeout(timer);
  }
}
