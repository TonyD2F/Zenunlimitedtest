#!/usr/bin/env node
/**
 * OpenCode Unlimited — zero-dependency gateway (Node 18+).
 */
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { URL } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DATA = path.join(ROOT, 'data');
const CONFIG_DIR = path.join(ROOT, 'config');
const CUSTOM_PROXIES = path.join(CONFIG_DIR, 'custom-proxies.txt');
const PORT = Number(process.env.PORT) || 8787;
const BIND = process.env.BIND || '127.0.0.1';
const UPSTREAM = process.env.OPENCODE_UPSTREAM || 'https://opencode.ai/zen/v1';
const UPSTREAM_ALT = 'https://opencode.ai/inference/openai/v1';
const MAX_RETRIES = 4;

for (const d of [DATA, CONFIG_DIR]) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

function parseProxyLine(line) {
  line = (line || '').trim();
  if (!line || line.startsWith('#')) return null;
  const m = line.match(/^(https?|socks[45]?):\/\/(?:([^:@]+):([^@]+)@)?([^:\/]+):(\d+)/i);
  if (m) return { protocol: m[1].toLowerCase(), host: m[4], port: +m[5], auth: m[2] ? m[2]+':'+m[3] : null };
  const parts = line.split(':');
  if (parts.length === 2 && !isNaN(parts[1])) return { protocol: 'http', host: parts[0], port: +parts[1], auth: null };
  if (parts.length === 4 && !isNaN(parts[1])) return { protocol: 'http', host: parts[0], port: +parts[1], auth: parts[2]+':'+parts[3] };
  return null;
}

function loadPersonal() {
  const list = [];
  try {
    if (fs.existsSync(CUSTOM_PROXIES)) {
      for (const line of fs.readFileSync(CUSTOM_PROXIES, 'utf8').split(/\r?\n/)) {
        const p = parseProxyLine(line);
        if (p) list.push(p);
      }
    }
  } catch {}
  const env = process.env.PROXY_CUSTOM || '';
  for (const part of env.split(/[,\n]/)) {
    const p = parseProxyLine(part);
    if (p) list.push(p);
  }
  return list;
}

const personal = loadPersonal();
let rr = 0;
const banned = new Map();

function nextProxy() {
  const list = personal.filter(p => {
    const k = p.host + ':' + p.port;
    const until = banned.get(k);
    if (until && Date.now() < until) return false;
    return true;
  });
  if (!list.length) return null;
  rr = (rr + 1) % list.length;
  return list[rr];
}

function ban(p, ms = 180000) {
  if (p) banned.set(p.host + ':' + p.port, Date.now() + ms);
}

function httpsRequest(urlStr, { method = 'GET', headers = {}, body, timeout = 60000 } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const opts = {
      hostname: u.hostname,
      port: u.port || 443,
      path: u.pathname + u.search,
      method,
      headers: { ...headers, Host: u.hostname },
      timeout
    };
    const req = https.request(opts, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8');
        let json = null;
        try { json = JSON.parse(raw); } catch {}
        resolve({ status: res.statusCode, headers: res.headers, raw, body: json });
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    if (body) req.write(typeof body === 'string' ? body : JSON.stringify(body));
    req.end();
  });
}

function applyFingerprint(body) {
  const out = { ...(body || {}) };
  if (out.stream === undefined) out.stream = true;
  return out;
}

let modelCache = { data: [], updated: 0 };

async function refreshModels() {
  for (const base of [UPSTREAM, UPSTREAM_ALT]) {
    try {
      const r = await httpsRequest(base + '/models', {
        headers: { Authorization: 'Bearer public', 'User-Agent': 'opencode/2.0' }
      });
      if (r.status === 200 && r.body && r.body.data) {
        modelCache = { data: r.body.data, updated: Date.now() };
        console.log('[models] loaded ' + modelCache.data.length + ' from ' + base);
        return;
      }
    } catch (e) {
      console.log('[models] ' + base + ' failed: ' + e.message);
    }
  }
  if (!modelCache.data.length) {
    modelCache = {
      data: [
        { id: 'deepseek-v4.1-flash-free', object: 'model' },
        { id: 'glm-5.3-flash-free', object: 'model' },
        { id: 'mimo-v2.6-flash-free', object: 'model' },
        { id: 'beam-free', object: 'model' },
        { id: 'big-pickle', object: 'model' },
        { id: 'flint-40b-free', object: 'model' },
        { id: 'nemotron-3.5-lightning-free', object: 'model' },
        { id: 'nemotron-3-ultra-free', object: 'model' }
      ],
      updated: Date.now()
    };
    console.log('[models] using static free-list fallback');
  }
}

await refreshModels();
setInterval(refreshModels, 30 * 60 * 1000);

function send(res, status, data, type = 'application/json') {
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { resolve({ _raw: raw }); }
    });
    req.on('error', reject);
  });
}

async function handleChat(req, res) {
  const incoming = await readBody(req);
  const body = applyFingerprint(incoming);
  let last = null;

  for (let i = 0; i < MAX_RETRIES; i++) {
    const base = i % 2 === 0 ? UPSTREAM : UPSTREAM_ALT;
    const proxy = nextProxy();
    try {
      const r = await httpsRequest(base + '/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: req.headers.authorization || 'Bearer public',
          'Content-Type': 'application/json',
          'User-Agent': 'opencode/2.0'
        },
        body
      });
      if (r.status === 429 || r.status === 403) {
        if (proxy) ban(proxy, r.status === 429 ? 600000 : 180000);
        last = r;
        continue;
      }
      if (r.status >= 200 && r.status < 300) {
        if (body.stream && typeof r.raw === 'string' && r.raw.includes('data:')) {
          res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Access-Control-Allow-Origin': '*'
          });
          res.end(r.raw);
          return;
        }
        return send(res, r.status, r.body ?? r.raw);
      }
      last = r;
    } catch (e) {
      last = { status: 502, body: { error: e.message } };
    }
  }
  send(res, last?.status || 502, last?.body || { error: 'upstream failed' });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');

  const url = req.url || '/';

  if (url === '/health' || url === '/healthz') {
    return send(res, 200, {
      ok: true,
      personalProxies: personal.length,
      banned: banned.size,
      models: modelCache.data.length,
      upstream: UPSTREAM
    });
  }

  if (url.startsWith('/v1/models') || url === '/models') {
    return send(res, 200, { object: 'list', data: modelCache.data });
  }

  if ((url === '/v1/chat/completions' || url === '/chat/completions') && req.method === 'POST') {
    return handleChat(req, res);
  }

  if (url === '/v1/messages' && req.method === 'POST') {
    const b = await readBody(req);
    const openai = {
      model: b.model,
      messages: b.messages || [],
      max_tokens: b.max_tokens,
      stream: b.stream,
      temperature: b.temperature
    };
    const body = applyFingerprint(openai);
    try {
      const r = await httpsRequest(UPSTREAM + '/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: req.headers.authorization || 'Bearer public',
          'Content-Type': 'application/json',
          'User-Agent': 'opencode/2.0'
        },
        body
      });
      return send(res, r.status, r.body ?? r.raw);
    } catch (e) {
      return send(res, 502, { error: e.message });
    }
  }

  if (url === '/' || url === '/index.html') {
    return send(res, 200, '<!DOCTYPE html><html><head><meta charset="utf-8"><title>OpenCode Unlimited</title><style>body{font-family:system-ui;background:#0f1115;color:#e6e6e6;margin:2rem}.card{background:#1a1d24;padding:1.2rem 1.5rem;border-radius:10px;max-width:560px}code{background:#2a2f3a;padding:.15rem .4rem;border-radius:4px}.ok{color:#4ade80}</style></head><body><div class="card"><h1>OpenCode Unlimited Gateway</h1><p>Status: <span class="ok">running</span></p><p>Personal proxies: <b>' + personal.length + '</b> · Models: <b>' + modelCache.data.length + '</b></p><p>OpenAI base: <code>http://' + BIND + ':' + PORT + '/v1</code></p><p>Health: <code>/health</code></p></div></body></html>', 'text/html');
  }

  send(res, 404, { error: 'not found' });
});

server.listen(PORT, BIND, () => {
  console.log('[opencode-unlimited] http://' + BIND + ':' + PORT);
  console.log('[opencode-unlimited] personal proxies: ' + personal.length);
  console.log('[opencode-unlimited] point clients at http://' + BIND + ':' + PORT + '/v1');
});
